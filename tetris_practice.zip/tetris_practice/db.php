<?
  $db_user="user";
  $db_pass="";
  $db_host="localhost";
  $db="tetris";
  $baseURL='demo.whitehotrobot.com';
  $link = mysqli_connect($db_host, $db_user, $db_pass, $db);
?>

